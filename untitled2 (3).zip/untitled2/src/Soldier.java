public class Soldier {

    public String name;//姓名
    public int level;//等级
    public int hp;//生命力
    public int atk;//攻击力
    public int def;//防御力


    public Soldier() {

    }

    public Soldier(String name, int level, int hp, int atk, int def) {//有参构造
        this.name = name;
        this.level = level;
        this.hp = hp;
        this.atk = atk;
        this.def = def;
    }

    public void attack(Soldier other) {
        int Damage = this.atk - other.def;
        other.hp -= Damage;
        if (other.hp <= 0) {
            System.out.println(other.name + "已经阵亡");
        } else {
            System.out.println("成功普通攻击了" + other.name + "并对它造成了" + Damage + "伤害" + other.name + "还剩" + other.hp + "血量");
        }

    }
}
