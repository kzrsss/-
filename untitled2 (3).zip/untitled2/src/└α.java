import java.util.Scanner;
public class 类 {
    public static void main(String[] args){
        class Person{
            String name;
            int age;
            public Person(String name,int age){
                this.name=name;
                this.age=age;
            }
            public void show(){
                System.out.println(name);
                System.out.println(age);
            }
        }
        Scanner sc=new Scanner(System.in);
        String i=sc.nextLine();
        Person zhangSan=new Person(i,18);
        zhangSan.show();
    }
}
