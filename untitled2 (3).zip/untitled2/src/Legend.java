import java.util.Scanner;
public class Legend {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入英雄的属性:名称，等级，生命，攻击力，防御力");
        String a= sc.nextLine();
        int b =sc.nextInt();
        int c=sc.nextInt();
        int d =sc.nextInt();
        int e =sc.nextInt();
        System.out.println("请输入小兵的属性:生命，攻击力，防御力");
        int g =sc.nextInt();
        int h=sc.nextInt();
        int i=sc.nextInt();
        Soldier yangke = new Soldier(a,b,c,d,e);
        Soldier xiaobing = new Soldier("小兵",50,g,h,i);
        yangke.attack(xiaobing);
    }
}
